#!/bin/bash

ps -ef | grep mycroft | grep -v grep